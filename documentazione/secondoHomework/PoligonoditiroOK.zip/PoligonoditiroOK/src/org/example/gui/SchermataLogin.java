package org.example.gui;

import org.example.controller.Controller;
import org.example.model.Commesso;
import javax.swing.*;
import java.awt.*;

public class SchermataLogin extends JFrame {
    private Controller controller;

    public SchermataLogin(Controller controller) {
        this.controller = controller;

        setTitle("Sistema di Accesso Armeria");
        setSize(400, 320);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(6, 1, 10, 10));

        getContentPane().setBackground(Color.decode("#2B2B2B"));

        JLabel lblTitolo = new JLabel("ACCESSO DI SICUREZZA RICHIESTO", SwingConstants.CENTER);
        lblTitolo.setFont(new Font("Impact", Font.PLAIN, 18));
        lblTitolo.setForeground(Color.decode("#D2C29D"));

        JLabel lblSotto = new JLabel("SELEZIONA PROFILO E INSERISCI CREDENZIALI", SwingConstants.CENTER);
        lblSotto.setFont(new Font("Arial", Font.BOLD, 11));
        lblSotto.setForeground(Color.LIGHT_GRAY);

        JComboBox<String> comboProfili = new JComboBox<>();
        comboProfili.setFont(new Font("Arial", Font.BOLD, 13));
        comboProfili.addItem("Supervisore: Mario Rossi");
        for (Commesso c : controller.getListaCommessi()) {
            comboProfili.addItem("Operatore: " + c.getNomeCompleto());
        }

        JPasswordField txtPass = new JPasswordField("•••••");
        txtPass.setHorizontalAlignment(JTextField.CENTER);
        txtPass.setBackground(Color.decode("#1E211E"));
        txtPass.setForeground(Color.decode("#D2C29D"));

        JButton btnLogin = new JButton("AUTENTICAZIONE SISTEMA");
        btnLogin.setFont(new Font("Impact", Font.PLAIN, 14));
        btnLogin.setBackground(Color.decode("#4A5D23"));
        btnLogin.setForeground(Color.decode("#D2C29D"));

        add(lblTitolo);
        add(lblSotto);
        add(comboProfili);
        add(txtPass);
        add(new JLabel());
        add(btnLogin);

        btnLogin.addActionListener(e -> {
            int index = comboProfili.getSelectedIndex();
            if (index == 0) {
                controller.setUtenteLoggato(controller.getSupervisore());
            } else {
                controller.setUtenteLoggato(controller.getListaCommessi().get(index - 1));
            }

            new InterfacciaGestionale(controller).setVisible(true);
            this.dispose();
        });
    }
}