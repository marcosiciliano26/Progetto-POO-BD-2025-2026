package org.example.gui;

import org.example.controller.Controller;
import org.example.model.Arma;
import org.example.model.Articolo;
import org.example.model.Commesso;
import org.example.model.VoceCarrello;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class InterfacciaGestionale extends JFrame {
    private Controller controller;
    private JLabel lblFinanze;
    private JTextArea txtStorico;
    private JTextArea txtMagazzino;
    private JTextArea txtClassifica;
    private JTextArea txtHR;
    private JComboBox<String> comboClienti;

    private JPanel pnlCheckout;
    private JTextArea txtCarrello;
    private JLabel lblTotaleCarrello;

    public InterfacciaGestionale(Controller controller) {
        this.controller = controller;
        applicaTemaMilitare();

        setTitle("Gestione Poligono di Tiro | Utente Attivo: " + controller.getUtenteLoggato().getNomeCompleto());
        setSize(1000, 720); // Finestra allargata per il layout a due colonne
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        Font fontInterfaccia = new Font("Arial", Font.BOLD, 13);
        Font fontTitoli = new Font("Impact", Font.PLAIN, 16);
        Font fontLedger = new Font("Courier New", Font.BOLD, 13);

        Color colorKhaki = Color.decode("#D2C29D");
        Color colorOlive = Color.decode("#4A5D23");

        // --- BARRA SUPERIORE (Tracciamento Finanziario Globale) ---
        JPanel pnlTopGlobal = new JPanel(new BorderLayout(15, 0));
        pnlTopGlobal.setBorder(BorderFactory.createEmptyBorder(15, 20, 10, 20));
        pnlTopGlobal.setOpaque(false);

        lblFinanze = new JLabel("", SwingConstants.LEFT);
        lblFinanze.setFont(new Font("Impact", Font.PLAIN, 22));
        lblFinanze.setForeground(Color.decode("#A4B573"));
        pnlTopGlobal.add(lblFinanze, BorderLayout.WEST);

        JButton btnLogout = new JButton("LOGOUT UTENTE");
        btnLogout.setFont(fontInterfaccia);
        btnLogout.setBackground(Color.decode("#7A291D"));
        btnLogout.setForeground(colorKhaki);
        btnLogout.setFocusPainted(false);
        btnLogout.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        btnLogout.setPreferredSize(new Dimension(140, 30));
        pnlTopGlobal.add(btnLogout, BorderLayout.EAST);

        btnLogout.addActionListener(e -> {
            controller.setUtenteLoggato(null);
            new SchermataLogin(controller).setVisible(true);
            this.dispose();
        });

        JPanel pnlDashboard = new JPanel(new BorderLayout(10, 10));
        pnlDashboard.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        txtStorico = new JTextArea();
        txtStorico.setEditable(false);
        txtStorico.setFont(fontLedger);
        txtStorico.setBackground(Color.decode("#1E211E"));
        txtStorico.setForeground(colorKhaki);

        JScrollPane scrollStorico = new JScrollPane(txtStorico);
        scrollStorico.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(colorOlive, 2),
                "REGISTRO OPERAZIONI POLIGONO", TitledBorder.LEFT, TitledBorder.TOP, fontTitoli, colorKhaki));
        pnlDashboard.add(scrollStorico, BorderLayout.CENTER);


        JPanel pnlCassaMain = new JPanel(new GridLayout(1, 2, 20, 0));
        pnlCassaMain.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        pnlCassaMain.setOpaque(false);


        JPanel pnlFormInserimento = new JPanel(new GridLayout(8, 2, 10, 15));
        pnlFormInserimento.setOpaque(false);
        pnlFormInserimento.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(colorOlive, 1),
                "1. DETTAGLI TRANSAZIONE", TitledBorder.LEFT, TitledBorder.TOP, fontTitoli, colorKhaki));


        comboClienti = new JComboBox<>();
        comboClienti.setFont(fontInterfaccia); comboClienti.setEditable(true);
        comboClienti.getEditor().getEditorComponent().setBackground(Color.decode("#1E211E"));
        comboClienti.getEditor().getEditorComponent().setForeground(colorKhaki);

        JComboBox<String> comboCommessi = new JComboBox<>(); comboCommessi.setFont(fontInterfaccia);
        for (Commesso c : controller.getListaCommessi()) comboCommessi.addItem(c.getNomeCompleto());

        JComboBox<String> comboCategoria = new JComboBox<>(new String[]{"Armi da Fuoco", "Munizioni e Accessori"});
        JComboBox<String> comboProdotti = new JComboBox<>();
        comboCategoria.setFont(fontInterfaccia); comboProdotti.setFont(fontInterfaccia);

        JRadioButton radNoleggio = new JRadioButton("Noleggio Poligono", true);
        JRadioButton radVendita = new JRadioButton("Vendita Dettaglio");
        radNoleggio.setFont(fontInterfaccia); radVendita.setFont(fontInterfaccia);
        radNoleggio.setOpaque(false); radVendita.setOpaque(false);
        ButtonGroup bgTipo = new ButtonGroup(); bgTipo.add(radNoleggio); bgTipo.add(radVendita);

        JPanel pnlRadio = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0)); pnlRadio.setOpaque(false);
        pnlRadio.add(radNoleggio); pnlRadio.add(radVendita);

        JLabel lblPrezzoDinamico = new JLabel("...");
        lblPrezzoDinamico.setFont(new Font("Arial", Font.BOLD, 14));
        lblPrezzoDinamico.setForeground(Color.decode("#A4B573"));

        // Pannello scambiabile per Punteggio (Noleggio) vs Quantità (Vendita)
        JPanel pnlDinamico = new JPanel(new CardLayout()); pnlDinamico.setOpaque(false);
        JTextField txtPunti = new JTextField("0"); txtPunti.setFont(fontInterfaccia);
        JTextField txtQuantita = new JTextField("1"); txtQuantita.setFont(fontInterfaccia);
        pnlDinamico.add(txtPunti, "PUNTI");
        pnlDinamico.add(txtQuantita, "QTA");

        JLabel lblTargetDinamico = creaLabelTattica("Punteggio Ottenuto:");

        JButton btnAzioneSingola = new JButton("AUTORIZZA NOLEGGIO");
        btnAzioneSingola.setFont(new Font("Impact", Font.PLAIN, 15));
        btnAzioneSingola.setFocusPainted(false);

        // LATO DESTRO: CARRELLO (Inizialmente invisibile perché partiamo da Noleggio)
        pnlCheckout = new JPanel(new BorderLayout(5, 10));
        pnlCheckout.setOpaque(false);
        pnlCheckout.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(colorOlive, 1),
                "2. CARRELLO VENDITA", TitledBorder.LEFT, TitledBorder.TOP, fontTitoli, colorKhaki));

        txtCarrello = new JTextArea("Carrello vuoto...\n");
        txtCarrello.setEditable(false); txtCarrello.setFont(fontLedger);
        txtCarrello.setBackground(Color.decode("#1E211E")); txtCarrello.setForeground(colorKhaki);

        JPanel pnlPulsantiCheckout = new JPanel(new BorderLayout()); pnlPulsantiCheckout.setOpaque(false);
        lblTotaleCarrello = new JLabel("TOTALE SCONTRINO: €0.00", SwingConstants.CENTER);
        lblTotaleCarrello.setFont(new Font("Impact", Font.PLAIN, 18));
        lblTotaleCarrello.setForeground(Color.decode("#A4B573"));

        JButton btnConcludi = new JButton("EMETTI SCONTRINO");
        btnConcludi.setFont(new Font("Impact", Font.PLAIN, 16));
        btnConcludi.setBackground(colorOlive);
        btnConcludi.setForeground(colorKhaki);
        JButton btnSvuota = new JButton("SVUOTA");
        btnSvuota.setFont(fontInterfaccia); btnSvuota.setBackground(Color.decode("#7A291D"));
        btnSvuota.setForeground(colorKhaki);

        pnlPulsantiCheckout.add(lblTotaleCarrello, BorderLayout.NORTH);
        pnlPulsantiCheckout.add(btnSvuota, BorderLayout.WEST);
        pnlPulsantiCheckout.add(btnConcludi, BorderLayout.CENTER);
        pnlCheckout.add(new JScrollPane(txtCarrello), BorderLayout.CENTER);
        pnlCheckout.add(pnlPulsantiCheckout, BorderLayout.SOUTH);

        Runnable aggiornaUIModo = () -> {
            CardLayout cl = (CardLayout) pnlDinamico.getLayout();
            if (radNoleggio.isSelected()) {
                pnlCheckout.setVisible(false); // Il carrello sparisce
                lblTargetDinamico.setText("Punteggio Ottenuto:");
                cl.show(pnlDinamico, "PUNTI");
                btnAzioneSingola.setText("AUTORIZZA NOLEGGIO");
                btnAzioneSingola.setBackground(colorOlive);
                btnAzioneSingola.setForeground(colorKhaki);
            } else {
                pnlCheckout.setVisible(true); // Il carrello compare
                lblTargetDinamico.setText("Quantità Selezionata:");
                cl.show(pnlDinamico, "QTA");
                btnAzioneSingola.setText("AGGIUNGI AL CARRELLO >>");
                btnAzioneSingola.setBackground(Color.decode("#9A7B4F")); // Khaki/Oro Tattico
                btnAzioneSingola.setForeground(Color.BLACK);
            }
        };

        Runnable aggiornaListaProdotti = () -> {
            comboProdotti.removeAllItems();
            if (comboCategoria.getSelectedIndex() == 0) {
                for (Arma a : controller.getMagazzino()) comboProdotti.addItem(a.getModello());
                radNoleggio.setEnabled(true);
            } else {
                for (Articolo a : controller.getInventarioArticoli()) comboProdotti.addItem(a.getNome());
                radNoleggio.setEnabled(false);
                radVendita.setSelected(true);
                aggiornaUIModo.run();
            }
        };

        Runnable aggiornaPrezzo = () -> {
            int idx = comboProdotti.getSelectedIndex();
            if (idx >= 0) {
                if (comboCategoria.getSelectedIndex() == 0) {
                    Arma a = controller.getMagazzino().get(idx);
                    lblPrezzoDinamico.setText(radNoleggio.isSelected() ? "€" + a.getCostoNoleggio() : "€" + a.getCostoVendita());
                } else {
                    lblPrezzoDinamico.setText("€" + controller.getInventarioArticoli().get(idx).getPrezzoVendita());
                }
            }
        };

        comboProdotti.addActionListener(e -> {
            aggiornaPrezzo.run();
            txtQuantita.setText("1");
        });

        comboCategoria.addActionListener(e -> { aggiornaListaProdotti.run(); aggiornaPrezzo.run(); });
        radNoleggio.addActionListener(e -> { aggiornaUIModo.run(); aggiornaPrezzo.run(); txtPunti.setText("0"); });
        radVendita.addActionListener(e -> { aggiornaUIModo.run(); aggiornaPrezzo.run(); txtQuantita.setText("1"); });

        // Costruzione Layout Form Sinistro (8 Righe perfette per evitare scritte tagliate)
        pnlFormInserimento.add(creaLabelTattica("Nome Cliente:")); pnlFormInserimento.add(comboClienti);
        pnlFormInserimento.add(creaLabelTattica("Staff al Banco:")); pnlFormInserimento.add(comboCommessi);
        pnlFormInserimento.add(creaLabelTattica("Categoria:")); pnlFormInserimento.add(comboCategoria);
        pnlFormInserimento.add(creaLabelTattica("Seleziona Articolo:")); pnlFormInserimento.add(comboProdotti);
        pnlFormInserimento.add(creaLabelTattica("Tipo Operazione:")); pnlFormInserimento.add(pnlRadio);
        pnlFormInserimento.add(creaLabelTattica("Costo Unitario:")); pnlFormInserimento.add(lblPrezzoDinamico);
        pnlFormInserimento.add(lblTargetDinamico); pnlFormInserimento.add(pnlDinamico);
        pnlFormInserimento.add(new JLabel()); pnlFormInserimento.add(btnAzioneSingola);

        pnlCassaMain.add(pnlFormInserimento);
        pnlCassaMain.add(pnlCheckout);

        aggiornaListaProdotti.run();
        aggiornaPrezzo.run();
        aggiornaUIModo.run();

        btnAzioneSingola.addActionListener(e -> {
            try {
                String nome = (String) comboClienti.getSelectedItem();
                int idxProd = comboProdotti.getSelectedIndex();
                int idxComm = comboCommessi.getSelectedIndex();
                boolean isArma = comboCategoria.getSelectedIndex() == 0;

                if (radNoleggio.isSelected()) {
                    int punti = Integer.parseInt(txtPunti.getText());
                    String esito = controller.registraTransazioneArma(nome, idxProd, idxComm, punti, 1, false);
                    JOptionPane.showMessageDialog(this, esito, "Esito Noleggio", JOptionPane.INFORMATION_MESSAGE);
                    aggiornaVista();
                    txtPunti.setText("0");
                } else {
                    int qta = Integer.parseInt(txtQuantita.getText());
                    String esito = controller.aggiungiAlCarrello(idxProd, isArma, qta, true, 0);
                    if (esito.startsWith("Errore")) JOptionPane.showMessageDialog(this, esito, "Attenzione", JOptionPane.WARNING_MESSAGE);
                    aggiornaCarrelloVista();
                    txtQuantita.setText("1"); // Reset immediato quantità post-aggiunta
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Valore numerico non valido.", "Errore", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnSvuota.addActionListener(e -> { controller.svuotaCarrello(); aggiornaCarrelloVista(); });

        btnConcludi.addActionListener(e -> {
            String nomeCliente = (String) comboClienti.getSelectedItem();
            int indiceCommesso = comboCommessi.getSelectedIndex();
            String esito = controller.eseguiCheckout(nomeCliente, indiceCommesso);

            if (esito.startsWith("Errore")) {
                JOptionPane.showMessageDialog(this, esito, "Errore Checkout", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, esito, "Scontrino Emesso", JOptionPane.INFORMATION_MESSAGE);
                aggiornaVista();
                aggiornaCarrelloVista();
                comboClienti.setSelectedItem(""); // Reset cliente
            }
        });

        JPanel pnlMagazzino = new JPanel(new BorderLayout(10, 10));
        pnlMagazzino.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        txtMagazzino = new JTextArea(); txtMagazzino.setEditable(false); txtMagazzino.setFont(fontLedger);
        txtMagazzino.setBackground(Color.decode("#1E211E")); txtMagazzino.setForeground(colorKhaki);
        pnlMagazzino.add(new JScrollPane(txtMagazzino), BorderLayout.CENTER);

        JPanel pnlRif = new JPanel(new FlowLayout(FlowLayout.LEFT)); pnlRif.setOpaque(false);
        JRadioButton radRifA = new JRadioButton("Armi", true);
        JRadioButton radRifArt = new JRadioButton("Accessori");
        ButtonGroup bgRif = new ButtonGroup(); bgRif.add(radRifA); bgRif.add(radRifArt);
        JComboBox<String> comboRif = new JComboBox<>();
        JTextField txtQtaRif = new JTextField("10", 5);
        JButton btnRif = new JButton("CARICA SCORTE");

        Runnable aggRif = () -> { comboRif.removeAllItems(); if(radRifA.isSelected()){ for(Arma a : controller.getMagazzino())
            comboRif.addItem(a.getModello()); } else { for(Articolo a : controller.getInventarioArticoli())
                comboRif.addItem(a.getNome()); } };
        radRifA.addActionListener(e->aggRif.run());
        radRifArt.addActionListener(e->aggRif.run());
        aggRif.run();

        btnRif.addActionListener(e -> { controller.rifornisciMagazzino(comboRif.getSelectedIndex(),
                Integer.parseInt(txtQtaRif.getText()), radRifA.isSelected()); aggiornaVista(); });
        pnlRif.add(radRifA); pnlRif.add(radRifArt); pnlRif.add(comboRif); pnlRif.add(txtQtaRif); pnlRif.add(btnRif);
        pnlMagazzino.add(pnlRif, BorderLayout.SOUTH);

        // --- SCHEDA 4: Leaderboard ---
        JPanel pnlPunteggi = new JPanel(new BorderLayout(10, 10));
        pnlPunteggi.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        txtClassifica = new JTextArea(); txtClassifica.setEditable(false); txtClassifica.setFont(fontLedger);
        txtClassifica.setBackground(Color.decode("#1E211E")); txtClassifica.setForeground(Color.decode("#A4B573"));
        pnlPunteggi.add(new JScrollPane(txtClassifica), BorderLayout.CENTER);

        tabbedPane.addTab("STATO FINANZIARIO", pnlDashboard);
        tabbedPane.addTab("CASSA E CARRELLO", pnlCassaMain);
        tabbedPane.addTab("INVENTARIO", pnlMagazzino);
        tabbedPane.addTab("CLASSIFICA", pnlPunteggi);

        // --- SCHEDA 5: Direzione HR ---
        if (controller.isSupervisoreLoggato()) {
            JPanel pnlHR = new JPanel(new BorderLayout(10, 10));
            pnlHR.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
            txtHR = new JTextArea(); txtHR.setEditable(false); txtHR.setFont(fontLedger); txtHR.setBackground(Color.decode("#1E211E")); txtHR.setForeground(Color.decode("#A4B573"));
            pnlHR.add(new JScrollPane(txtHR), BorderLayout.CENTER);
            tabbedPane.addTab("DIREZIONE (HR)", pnlHR);
        }

        add(pnlTopGlobal, BorderLayout.NORTH);
        add(tabbedPane, BorderLayout.CENTER);

        aggiornaVista();
    }

    private void aggiornaCarrelloVista() {
        txtCarrello.setText("");
        if (controller.getCarrello().isEmpty()) {
            txtCarrello.setText("Nessun articolo nel carrello...\nPronto per la vendita.");
        } else {
            for (VoceCarrello v : controller.getCarrello()) {
                txtCarrello.append(String.format("- %dx %s = €%.2f\n", v.getQuantita(), v.getNomeProdotto(), v.getPrezzoTotale()));
            }
        }
        lblTotaleCarrello.setText(String.format("TOTALE SCONTRINO: €%.2f", controller.getTotaleCarrello()));
    }

    private JLabel creaLabelTattica(String testo) {
        JLabel lbl = new JLabel(testo);
        lbl.setFont(new Font("Impact", Font.PLAIN, 15));
        lbl.setForeground(Color.decode("#D2C29D"));
        return lbl;
    }

    private void applicaTemaMilitare() {
        try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
        catch (Exception e) { e.printStackTrace(); }

        Color bgGunmetal = Color.decode("#2B2B2B"); Color bgCampi = Color.decode("#1E211E");
        Color testoKhaki = Color.decode("#D2C29D"); Color verdeOliva = Color.decode("#4A5D23");

        UIManager.put("Panel.background", bgGunmetal);
        UIManager.put("TabbedPane.background", bgGunmetal);
        UIManager.put("TabbedPane.foreground", testoKhaki);
        UIManager.put("TabbedPane.selected", verdeOliva);
        UIManager.put("TabbedPane.contentAreaColor", bgGunmetal);
        UIManager.put("Label.foreground", testoKhaki);
        UIManager.put("RadioButton.background", bgGunmetal);
        UIManager.put("RadioButton.foreground", testoKhaki);
        UIManager.put("TextField.background", bgCampi);
        UIManager.put("TextField.foreground", testoKhaki);
        UIManager.put("TextField.caretForeground", Color.WHITE);
        UIManager.put("TextField.border", BorderFactory.createLineBorder(Color.BLACK, 1));
        UIManager.put("ComboBox.background", bgCampi);
        UIManager.put("ComboBox.foreground", testoKhaki);
        UIManager.put("ComboBox.selectionBackground", verdeOliva);
        UIManager.put("ComboBox.selectionForeground", testoKhaki);
        UIManager.put("OptionPane.background", bgGunmetal);
        UIManager.put("OptionPane.messageForeground", testoKhaki);
        UIManager.put("Button.background", verdeOliva);
        UIManager.put("Button.foreground", testoKhaki);
    }

    private void aggiornaVista() {
        lblFinanze.setText(controller.getDatiFinanziari());

        Object currentSelection = comboClienti.getSelectedItem();
        comboClienti.removeAllItems();
        for (String nome : controller.getNomiClienti()) comboClienti.addItem(nome);
        if (currentSelection != null) comboClienti.setSelectedItem(currentSelection);

        txtStorico.setText("=== REGISTRO UFFICIALE POLIGONO ===\n\n");
        for (String log : controller.getStoricoSessioni()) txtStorico.append("[LOG] " + log + "\n");

        txtMagazzino.setText("=== REPORT SCORTE: ARMI ===\n");
        for (Arma a : controller.getMagazzino()) {
            txtMagazzino.append(String.format("%-15s | IN MAGAZZINO: %02d | PREZZO: €%.2f\n",
                    a.getModello(), a.getQuantitaMagazzino(), a.getCostoVendita()));
        }

        txtMagazzino.append("\n=== REPORT SCORTE: ACCESSORI & MUNIZIONI ===\n");
        for (Articolo a : controller.getInventarioArticoli()) {
            txtMagazzino.append(String.format("[%s] %-25s | COMPATIBILITA': %-12s | IN MAGAZZINO: %02d | PREZZO: €%.2f\n",
                    a.getCategoria(), a.getNome(), a.getCompatibilita(), a.getQuantitaMagazzino(), a.getPrezzoVendita()));
        }

        txtClassifica.setText("=== CLASSIFICA POLIGONO ===\n\n");
        for (String score : controller.getClassifica()) txtClassifica.append("> " + score + "\n");

        if (controller.isSupervisoreLoggato() && txtHR != null) {
            txtHR.setText("=== REVISIONE STAFF E DIREZIONE (CONFIDENZIALE) ===\n\n");
            txtHR.append(String.format("STIPENDIO BASE SUPERVISORE: €%.2f\n", controller.getSupervisore().getStipendio()));
            txtHR.append("----------------------------------------------------------------------\n");
            for (Commesso c : controller.getListaCommessi()) {
                txtHR.append(String.format("OPERATORE: %-18s | STIPENDIO BASE: €%.2f | RICAVI TOTALI GENERATI: €%.2f\n",
                        c.getNomeCompleto(), c.getStipendio(), c.getIncassiGenerati()));
            }
        }
    }
}