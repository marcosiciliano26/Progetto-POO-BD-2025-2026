package org.example.model;

public class Commesso extends Persona {
    private String matricola;
    private double stipendio;
    private double incassiGenerati;

    public Commesso(String nome, String cognome, String matricola, double stipendio) {
        super(nome, cognome);
        this.matricola = matricola;
        this.stipendio = stipendio;
        this.incassiGenerati = 0.0;
    }

    public String getMatricola() { return matricola; }
    public double getStipendio() { return stipendio; }
    public double getIncassiGenerati() { return incassiGenerati; }

    public void aggiungiIncasso(double importo) {
        this.incassiGenerati += importo;
    }
}