package org.example.model;

public class Arma {
    private String modello;
    private int quantitaMagazzino;
    private double costoNoleggio;
    private double costoVendita;

    public Arma(String modello, int quantitaMagazzino, double costoNoleggio, double costoVendita) {
        this.modello = modello;
        this.quantitaMagazzino = quantitaMagazzino;
        this.costoNoleggio = costoNoleggio;
        this.costoVendita = costoVendita;
    }

    public String getModello() { return modello; }
    public int getQuantitaMagazzino() { return quantitaMagazzino; }
    public double getCostoNoleggio() { return costoNoleggio; }
    public double getCostoVendita() { return costoVendita; }

    public void riduciScorta(int quantita) {
        if (quantitaMagazzino >= quantita) {
            quantitaMagazzino -= quantita;
        }
    }

    // Nuovo metodo per il rifornimento
    public void aggiungiScorta(int quantita) {
        if (quantita > 0) {
            this.quantitaMagazzino += quantita;
        }
    }
}