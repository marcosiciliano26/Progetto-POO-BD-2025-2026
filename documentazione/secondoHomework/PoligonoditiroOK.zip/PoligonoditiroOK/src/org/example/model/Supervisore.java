package org.example.model;

public class Supervisore extends Persona {
    private int livelloAutorizzazione;
    private double stipendio;

    public Supervisore(String nome, String cognome, int livelloAutorizzazione, double stipendio) {
        super(nome, cognome);
        this.livelloAutorizzazione = livelloAutorizzazione;
        this.stipendio = stipendio;
    }

    public int getLivelloAutorizzazione() { return livelloAutorizzazione; }
    public double getStipendio() { return stipendio; }
}