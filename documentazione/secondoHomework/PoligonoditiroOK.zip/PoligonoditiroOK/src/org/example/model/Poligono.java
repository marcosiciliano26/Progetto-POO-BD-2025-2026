package org.example.model;

import java.util.ArrayList;
import java.util.List;

public class Poligono {
    private double incassi;
    private double spese;
    private List<String> registroSessioni;
    private List<String> classificaPunteggi; // Nuova lista dedicata ai punteggi

    public Poligono() {
        this.incassi = 0.0;
        this.spese = 0.0;
        this.registroSessioni = new ArrayList<>();
        this.classificaPunteggi = new ArrayList<>();
    }

    public void aggiungiIncasso(double importo) { this.incassi += importo; }
    public void aggiungiSpesa(double importo) { this.spese += importo; }

    public double getIncassi() { return incassi; }
    public double getSpese() { return spese; }
    public double getProfitti() { return incassi - spese; }

    public void registraOperazione(String nomeCliente, String dettaglio, int punteggio) {
        String log = "Cliente: " + nomeCliente + " | Op: " + dettaglio + " | Punti sessione: " + punteggio;
        registroSessioni.add(log);
    }

    public void registraPunteggio(String nomeCliente, String armaUsata, int punteggio) {
        String scoreLog = "Tiratore: " + nomeCliente + " | Arma: " + armaUsata + " | Score: " + punteggio + " pt.";
        classificaPunteggi.add(scoreLog);
    }

    public List<String> getRegistroSessioni() { return registroSessioni; }
    public List<String> getClassificaPunteggi() { return classificaPunteggi; }
}