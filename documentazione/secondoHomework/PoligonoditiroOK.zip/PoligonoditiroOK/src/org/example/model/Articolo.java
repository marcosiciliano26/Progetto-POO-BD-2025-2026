package org.example.model;

public class Articolo {
    private String nome;
    private String categoria;
    private String compatibilita;
    private int quantitaMagazzino;
    private double prezzoVendita;

    public Articolo(String nome, String categoria, String compatibilita, int quantitaMagazzino, double prezzoVendita) {
        this.nome = nome;
        this.categoria = categoria;
        this.compatibilita = compatibilita;
        this.quantitaMagazzino = quantitaMagazzino;
        this.prezzoVendita = prezzoVendita;
    }

    public String getNome() { return nome; }
    public String getCategoria() { return categoria; }
    public String getCompatibilita() { return compatibilita; }
    public int getQuantitaMagazzino() { return quantitaMagazzino; }
    public double getPrezzoVendita() { return prezzoVendita; }

    public void riduciScorta(int quantita) {
        if (quantitaMagazzino >= quantita) {
            quantitaMagazzino -= quantita;
        }
    }

    public void aggiungiScorta(int quantita) {
        if (quantita > 0) {
            this.quantitaMagazzino += quantita;
        }
    }
}