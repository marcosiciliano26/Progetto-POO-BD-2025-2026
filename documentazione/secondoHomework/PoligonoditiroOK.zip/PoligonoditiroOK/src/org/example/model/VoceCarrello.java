package org.example.model;

public class VoceCarrello {
    private boolean isArma;
    private int indiceMagazzino;
    private String nomeProdotto;
    private int quantita;
    private boolean isVendita;
    private int punteggio;
    private double prezzoTotale;

    public VoceCarrello(boolean isArma, int indiceMagazzino, String nomeProdotto, int quantita, boolean isVendita, int punteggio, double prezzoTotale)
    {
        this.isArma = isArma;
        this.indiceMagazzino = indiceMagazzino;
        this.nomeProdotto = nomeProdotto;
        this.quantita = quantita;
        this.isVendita = isVendita;
        this.punteggio = punteggio;
        this.prezzoTotale = prezzoTotale;
    }

    public boolean isArma() { return isArma; }
    public int getIndiceMagazzino() { return indiceMagazzino; }
    public String getNomeProdotto() { return nomeProdotto; }
    public int getQuantita() { return quantita; }
    public boolean isVendita() { return isVendita; }
    public int getPunteggio() { return punteggio; }
    public double getPrezzoTotale() { return prezzoTotale; }
}