package org.example.controller;

import org.example.model.*;
import java.util.ArrayList;
import java.util.List;

public class Controller {
    private Poligono poligono;
    private List<Arma> magazzinoArmi;
    private List<Articolo> inventarioArticoli;
    private List<Commesso> listaCommessi;
    private Supervisore supervisore;
    private List<Persona> clientiRegistrati;
    private Persona utenteLoggato;

    private List<VoceCarrello> carrelloSessione;

    public Controller() {
        this.poligono = new Poligono();
        this.magazzinoArmi = new ArrayList<>();
        this.inventarioArticoli = new ArrayList<>();
        this.listaCommessi = new ArrayList<>();
        this.clientiRegistrati = new ArrayList<>();
        this.carrelloSessione = new ArrayList<>();

        this.supervisore = new Supervisore("Mario", "Rossi", 3, 2500.00);

        listaCommessi.add(new Commesso("Marco", "Siciliano", "C-101", 1300.00));
        listaCommessi.add(new Commesso("Nicolò", "Stendardo", "C-102", 1350.00));

        clientiRegistrati.add(new Persona("John", "Wick"));
        clientiRegistrati.add(new Persona("Chris", "Kyle"));

        poligono.aggiungiSpesa(supervisore.getStipendio());
        for (Commesso c : listaCommessi) {
            poligono.aggiungiSpesa(c.getStipendio());
        }

        magazzinoArmi.add(new Arma("Glock 19", 10, 25.0, 600.0));
        magazzinoArmi.add(new Arma("M4A1", 3, 50.0, 1200.0));
        magazzinoArmi.add(new Arma("Carabina .22", 5, 15.0, 350.0));

        inventarioArticoli.add(new Articolo("Scatola 9mm (50 pz)", "Munizioni", "Glock 19", 50, 18.50));
        inventarioArticoli.add(new Articolo("Scatola 5.56mm (30 pz)", "Munizioni", "M4A1", 100, 22.00));
        inventarioArticoli.add(new Articolo("Mimetica Desert Camo", "Mimetica", "M4A1", 12, 45.00));
        inventarioArticoli.add(new Articolo("Mirino Olografico", "Accessorio", "Universale", 8, 120.00));
        inventarioArticoli.add(new Articolo("Silenziatore Tattico", "Accessorio", "Universale", 5, 85.00));
    }

    public void setUtenteLoggato(Persona utente) { this.utenteLoggato = utente; }
    public Persona getUtenteLoggato() { return utenteLoggato; }
    public Supervisore getSupervisore() { return supervisore; }
    public boolean isSupervisoreLoggato() { return utenteLoggato instanceof Supervisore; }

    public List<Arma> getMagazzino() { return magazzinoArmi; }
    public List<Articolo> getInventarioArticoli() { return inventarioArticoli; }
    public List<Commesso> getListaCommessi() { return listaCommessi; }
    public List<VoceCarrello> getCarrello() { return carrelloSessione; }

    public List<String> getNomiClienti() {
        List<String> nomi = new ArrayList<>();
        for (Persona p : clientiRegistrati) nomi.add(p.getNomeCompleto());
        return nomi;
    }

    public String getDatiFinanziari() {
        return String.format("Incassi: €%.2f | Spese Fisse: €%.2f | Profitti Netti: €%.2f",
                poligono.getIncassi(), poligono.getSpese(), poligono.getProfitti());
    }

    public List<String> getStoricoSessioni() { return poligono.getRegistroSessioni(); }
    public List<String> getClassifica() { return poligono.getClassificaPunteggi(); }

    public void svuotaCarrello() { carrelloSessione.clear(); }
    public double getTotaleCarrello() {
        return carrelloSessione.stream().mapToDouble(VoceCarrello::getPrezzoTotale).sum();
    }

    public String registraTransazioneArma(String nomeCliente, int indiceArma, int indiceCommesso, int punteggio, int quantita, boolean isVendita) {
        String nomePulito = nomeCliente.trim();
        if (nomePulito.isEmpty()) return "Errore: Inserire o selezionare il nome del cliente.";
        if (quantita <= 0) return "Errore: La quantità deve essere almeno 1.";

        boolean clienteEsistente = false;
        for (Persona p : clientiRegistrati) {
            if (p.getNomeCompleto().equalsIgnoreCase(nomePulito)) {
                clienteEsistente = true;
                break;
            }
        }

        if (!clienteEsistente) {
            String[] parti = nomePulito.split(" ", 2);
            clientiRegistrati.add(new Persona(parti[0], (parti.length > 1) ? parti[1] : ""));
        }

        Arma armaScelta = magazzinoArmi.get(indiceArma);
        Commesso commessoScelto = listaCommessi.get(indiceCommesso);
        String dettagliOperazione = " (Gestito da: " + commessoScelto.getNomeCompleto() + ")";

        if (isVendita) {
            if (armaScelta.getQuantitaMagazzino() < quantita) {
                return "Errore: Scorte insufficienti! Unità disponibili: " + armaScelta.getQuantitaMagazzino();
            }
            armaScelta.riduciScorta(quantita);
            double incassoTotale = armaScelta.getCostoVendita() * quantita;

            poligono.aggiungiIncasso(incassoTotale);
            commessoScelto.aggiungiIncasso(incassoTotale);

            poligono.registraOperazione(nomePulito, "Acquisto " + quantita + "x " + armaScelta.getModello() + dettagliOperazione, 0);
            return "Successo: " + quantita + "x " + armaScelta.getModello() + " vendute. Incassato €" + incassoTotale;
        } else {
            double tariffaNoleggio = armaScelta.getCostoNoleggio();
            poligono.aggiungiIncasso(tariffaNoleggio);
            commessoScelto.aggiungiIncasso(tariffaNoleggio);

            poligono.registraOperazione(nomePulito, "Noleggio " + armaScelta.getModello() + dettagliOperazione, punteggio);
            poligono.registraPunteggio(nomePulito, armaScelta.getModello(), punteggio);

            return "Successo: Noleggio registrato. Incassato €" + tariffaNoleggio;
        }
    }

    public String aggiungiAlCarrello(int indiceProdotto, boolean isArma, int quantita, boolean isVendita, int punteggio) {
        if (quantita <= 0) return "Errore: La quantità deve essere almeno 1.";

        int qtaGiaInCarrello = 0;
        for (VoceCarrello v : carrelloSessione) {
            if (v.isArma() == isArma && v.getIndiceMagazzino() == indiceProdotto && v.isVendita()) {
                qtaGiaInCarrello += v.getQuantita();
            }
        }

        if (isArma) {
            Arma arma = magazzinoArmi.get(indiceProdotto);
            if (isVendita && (qtaGiaInCarrello + quantita > arma.getQuantitaMagazzino())) {
                return "Errore: Scorte di " + arma.getModello() + " insufficienti per questa aggiunta.";
            }
            double prezzo = isVendita ? arma.getCostoVendita() * quantita : arma.getCostoNoleggio();
            carrelloSessione.add(new VoceCarrello(true, indiceProdotto, arma.getModello(), quantita, isVendita, punteggio, prezzo));
            return "Aggiunto: " + (isVendita ? quantita + "x (Vendita) " : "(Noleggio) ") + arma.getModello();
        } else {
            Articolo art = inventarioArticoli.get(indiceProdotto);
            if (qtaGiaInCarrello + quantita > art.getQuantitaMagazzino()) {
                return "Errore: Scorte di " + art.getNome() + " insufficienti.";
            }
            double prezzo = art.getPrezzoVendita() * quantita;
            carrelloSessione.add(new VoceCarrello(false, indiceProdotto, art.getNome(), quantita, true, 0, prezzo));
            return "Aggiunto: " + quantita + "x " + art.getNome();
        }
    }

    public String eseguiCheckout(String nomeCliente, int indiceCommesso) {
        if (carrelloSessione.isEmpty()) return "Errore: Il carrello è vuoto.";

        String nomePulito = nomeCliente.trim();
        if (nomePulito.isEmpty()) return "Errore: Inserire o selezionare il nome del cliente.";

        boolean clienteEsistente = false;
        for (Persona p : clientiRegistrati) {
            if (p.getNomeCompleto().equalsIgnoreCase(nomePulito))
            {
                clienteEsistente = true;
                break;
            }
        }
        if (!clienteEsistente) {
            String[] parti = nomePulito.split(" ", 2);
            clientiRegistrati.add(new Persona(parti[0], (parti.length > 1) ? parti[1] : ""));
        }

        Commesso commessoScelto = listaCommessi.get(indiceCommesso);
        double totaleScontrino = 0.0;
        int totalePunti = 0;
        StringBuilder dettagliLog = new StringBuilder("SCONTRINO (Gestito da: " + commessoScelto.getNomeCompleto() + ") -> ");

        for (VoceCarrello voce : carrelloSessione) {
            totaleScontrino += voce.getPrezzoTotale();
            if (voce.isArma()) {
                Arma a = magazzinoArmi.get(voce.getIndiceMagazzino());
                if (voce.isVendita()) {
                    a.riduciScorta(voce.getQuantita());
                    dettagliLog.append("[").append(voce.getQuantita()).append("x Vendita ").append(a.getModello()).append("] ");
                } else {
                    dettagliLog.append("[Noleggio ").append(a.getModello()).append("] ");
                    if (voce.getPunteggio() > 0) {
                        poligono.registraPunteggio(nomePulito, a.getModello(), voce.getPunteggio());
                        totalePunti += voce.getPunteggio();
                    }
                }
            } else {
                Articolo art = inventarioArticoli.get(voce.getIndiceMagazzino());
                art.riduciScorta(voce.getQuantita());
                dettagliLog.append("[").append(voce.getQuantita()).append("x ").append(art.getNome()).append("] ");
            }
        }

        poligono.aggiungiIncasso(totaleScontrino);
        commessoScelto.aggiungiIncasso(totaleScontrino);
        poligono.registraOperazione(nomePulito, dettagliLog.toString(), totalePunti);

        svuotaCarrello();
        return String.format("CHECKOUT COMPLETATO!\nTotale incassato: €%.2f\nCliente: %s", totaleScontrino, nomePulito);
    }

    public String rifornisciMagazzino(int indice, int quantita, boolean isArma) {
        if (quantita <= 0) return "Errore: Inserire una quantità maggiore di zero.";
        if (isArma) {
            magazzinoArmi.get(indice).aggiungiScorta(quantita);
            return "SCORTE AGGIORNATE: +" + quantita + " unità (Arma)";
        } else {
            inventarioArticoli.get(indice).aggiungiScorta(quantita);
            return "SCORTE AGGIORNATE: +" + quantita + " unità (Articolo/Munizioni)";
        }
    }
}