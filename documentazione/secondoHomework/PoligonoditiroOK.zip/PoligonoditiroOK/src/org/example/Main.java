package org.example;

import org.example.controller.Controller;
import org.example.gui.SchermataLogin;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Controller controller = new Controller();
            SchermataLogin loginScreen = new SchermataLogin(controller);
            loginScreen.setVisible(true);
        });
    }
}